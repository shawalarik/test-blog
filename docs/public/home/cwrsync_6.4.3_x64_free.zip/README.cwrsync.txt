cwRsync 6.4.3 - Rsync client for Windows
June 2025, provided by itefix.net - https://www.itefix.net/cwrsync

This archive contains a barebone distribution of Rsync for Windows.

- Unzip archive contents to a directory
- update the supplied batch file cwrsync.cmd.

That's all you need to be able to initiate rsync connectionsfrom
from a command line.

We provide paid versions of cwRsync with a helper GUI or setup as a server.
See https://www.itefix.net/cwrsync for more information.

ENJOY RSYNC!!

Version information:
Rsync 3.4.1
Cygwin 3.6.3
OpenSSH 10.0p2
OpenSSL 3.0.16

Output of 'rsync --version':
----------------------------
rsync  version 3.4.1  protocol version 32
Copyright (C) 1996-2025 by Andrew Tridgell, Wayne Davison, and others.
Web site: https://rsync.samba.org/
Capabilities:
    64-bit files, 64-bit inums, 64-bit timestamps, 64-bit long ints,
    socketpairs, symlinks, symtimes, hardlinks, no hardlink-specials,
    hardlink-symlinks, IPv6, atimes, batchfiles, inplace, append, no ACLs,
    no xattrs, optional secluded-args, iconv, prealloc, stop-at, crtimes
Optimizations:
    no SIMD-roll, no asm-roll, openssl-crypto, no asm-MD5
Checksum list:
    xxh128 xxh3 xxh64 (xxhash) md5 md4 sha1 none
Compress list:
    zstd lz4 zlibx zlib none
Daemon auth list:
    sha512 sha256 sha1 md5 md4

rsync comes with ABSOLUTELY NO WARRANTY.  This is free software, and you
are welcome to redistribute it under certain conditions.  See the GNU
General Public Licence for details.



Output of 'ssh -V':
-------------------
OpenSSH_10.0p2, OpenSSL 3.0.16 11 Feb 2025
